import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const EnglishCoachApp());

const navy = Color(0xFF101B36);
const blue = Color(0xFF536DFE);
const lessons = [
  {'title':'Introduce Yourself','level':'Beginner','en':'Hello, my name is Rahul. I study in class ten.','hi':'नमस्ते, मेरा नाम राहुल है। मैं दसवीं कक्षा में पढ़ता हूँ।'},
  {'title':'At School','level':'Beginner','en':'Could you please explain this question?','hi':'क्या आप कृपया यह सवाल समझा सकते हैं?'},
  {'title':'Daily Conversation','level':'Beginner','en':'What are your plans for the weekend?','hi':'वीकेंड के लिए तुम्हारा क्या प्लान है?'},
  {'title':'Speak with Confidence','level':'Intermediate','en':'In my opinion, practice is the key to improvement.','hi':'मेरे विचार से अभ्यास सुधार की कुंजी है।'},
  {'title':'Class Presentation','level':'Intermediate','en':'Good morning everyone. Today I am going to talk about the environment.','hi':'सभी को सुप्रभात। आज मैं पर्यावरण के बारे में बात करने जा रहा हूँ।'},
  {'title':'Future Goals','level':'Intermediate','en':'I want to improve my communication skills and achieve my goals.','hi':'मैं अपनी बातचीत की क्षमता सुधारना और अपने लक्ष्य हासिल करना चाहता हूँ।'},
];

class EnglishCoachApp extends StatelessWidget {
  const EnglishCoachApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SpeakUp English',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: blue), scaffoldBackgroundColor: const Color(0xFFF5F7FC), fontFamily: 'Roboto'),
    home: const HomeScreen(),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int grade = 10, completed = 0, tab = 0;
  String name = 'Student';
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() { grade = p.getInt('grade') ?? 10; completed = p.getInt('completed') ?? 0; name = p.getString('name') ?? 'Student'; });
  }
  Future<void> _setGrade(int g) async { final p=await SharedPreferences.getInstance(); await p.setInt('grade',g); setState(()=>grade=g); }
  Future<void> _done() async { final p=await SharedPreferences.getInstance(); await p.setInt('completed',++completed); setState((){}); }
  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      PracticeScreen(onComplete: _done),
      const TutorScreen(),
      const ProgressScreen(),
    ];
    return Scaffold(
      appBar: AppBar(backgroundColor: navy, foregroundColor: Colors.white, title: const Row(children:[Icon(Icons.record_voice_over_rounded), SizedBox(width:9), Text('SpeakUp English', style: TextStyle(fontWeight: FontWeight.bold))]), actions:[PopupMenuButton<int>(tooltip:'Choose class', onSelected:_setGrade, itemBuilder:(c)=>[9,10,11].map((g)=>PopupMenuItem(value:g,child:Text('Class $g'))).toList(), icon: const Icon(Icons.school))]),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const [
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.mic_none),selectedIcon:Icon(Icons.mic),label:'Practice'),
        NavigationDestination(icon:Icon(Icons.smart_toy_outlined),selectedIcon:Icon(Icons.smart_toy),label:'AI Tutor'),
        NavigationDestination(icon:Icon(Icons.trending_up),label:'Progress'),
      ]),
    );
  }
  Widget _home() => ListView(padding:const EdgeInsets.all(18),children:[
    Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[navy,Color(0xFF293D70)]),borderRadius:BorderRadius.circular(24)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('CLASS $grade • ENGLISH SPEAKING',style:const TextStyle(color:Color(0xFFBFCBFF),fontWeight:FontWeight.bold,letterSpacing:1)),
      const SizedBox(height:12),Text('Speak confidently,\\n$name!',style:const TextStyle(color:Colors.white,fontSize:27,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),const Text('Small daily practice. Real progress.',style:TextStyle(color:Colors.white70)),
      const SizedBox(height:18),Row(children:[const Icon(Icons.local_fire_department,color:Colors.orange),const SizedBox(width:6),Text('$completed lessons completed',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w600))])
    ])),
    const SizedBox(height:22),const Text('Your learning path',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    _tile(Icons.record_voice_over,'Speaking practice','Speak aloud and check what was recognised',()=>setState(()=>tab=1),const Color(0xFFE8ECFF)),
    _tile(Icons.smart_toy,'AI conversation tutor','Practise everyday English conversations',()=>setState(()=>tab=2),const Color(0xFFE1F7EE)),
    _tile(Icons.menu_book,'Grammar & useful phrases','Learn with simple Hindi explanations',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const LessonsScreen())),const Color(0xFFFFF0D9)),
    const SizedBox(height:18),const Text('Daily tip',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('गलती करने से मत डरें। रोज़ 5 मिनट अंग्रेज़ी में बोलें और छोटे वाक्यों से शुरुआत करें।',style:TextStyle(fontSize:15)))),
  ]);
  Widget _tile(IconData icon,String title,String sub,VoidCallback tap,Color color)=>Card(elevation:0,child:ListTile(onTap:tap,contentPadding:const EdgeInsets.all(12),leading:CircleAvatar(backgroundColor:color,child:Icon(icon,color:navy)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(sub),trailing:const Icon(Icons.arrow_forward_ios,size:16)));
}

class LessonsScreen extends StatelessWidget {
  const LessonsScreen({super.key});
  @override
  Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Lessons & phrases')),body:ListView.builder(padding:const EdgeInsets.all(16),itemCount:lessons.length,itemBuilder:(c,i){final l=lessons[i];return Card(child:ListTile(isThreeLine:true,title:Text(l['title']!,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${l['en']}\n${l['hi']}'),trailing:const Icon(Icons.menu_book)));}));
}

class PracticeScreen extends StatefulWidget {
  final VoidCallback onComplete;
  const PracticeScreen({super.key,required this.onComplete});
  @override
  State<PracticeScreen> createState()=>_PracticeScreenState();
}
class _PracticeScreenState extends State<PracticeScreen>{
  final stt.SpeechToText speech=stt.SpeechToText();
  final FlutterTts tts=FlutterTts();
  String heard='', message='Tap the microphone and say the sentence.';
  bool listening=false;
  int index=0;
  Map<String,String> get lesson=>lessons[index%lessons.length];
  Future<void> _speak() async { await tts.setLanguage('en-IN'); await tts.setSpeechRate(0.42); await tts.speak(lesson['en']!); }
  Future<void> _listen() async {
    if(listening){await speech.stop();setState(()=>listening=false);return;}
    final available=await speech.initialize(onStatus:(s){if(s=='done'&&mounted)setState(()=>listening=false);},onError:(e){if(mounted)setState(()=>message='Speech recognition unavailable. Check microphone permission or try again.');});
    if(!available){setState(()=>message='Speech recognition is not available on this device.');return;}
    setState(()=>{listening=true,heard='',message='Listening… speak clearly.'});
    await speech.listen(localeId:'en_IN',listenFor:const Duration(seconds:25),onResult:(r){if(mounted)setState(()=>heard=r.recognizedWords);});
  }
  String feedback(){
    if(heard.trim().isEmpty)return 'पहले माइक्रोफ़ोन दबाकर वाक्य बोलें।';
    final target=lesson['en']!.toLowerCase().replaceAll(RegExp(r'[^a-z ]'),'').split(' ').where((x)=>x.isNotEmpty).toSet();
    final said=heard.toLowerCase().replaceAll(RegExp(r'[^a-z ]'),'').split(' ').where((x)=>x.isNotEmpty).toSet();
    final common=target.intersection(said).length;
    final pct=(common/target.length*100).round();
    return pct>=75?'Great effort! कई शब्द सही पहचाने गए। अब मॉडल वाक्य सुनें और दोबारा बोलें.':'Good try! मॉडल वाक्य सुनें, फिर धीरे-धीरे दोबारा बोलें। यह केवल शब्द-मिलान है, सटीक accent scoring नहीं।';
  }
  @override
  void dispose(){speech.stop();tts.stop();super.dispose();}
  @override
  Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Speak & practise',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
    const SizedBox(height:6),const Text('Listen first, then say the sentence in English.'),
    const SizedBox(height:18),Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('LESSON ${index+1} • ${lesson['level']!.toUpperCase()}',style:const TextStyle(color:blue,fontWeight:FontWeight.bold)),
      const SizedBox(height:12),Text(lesson['en']!,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),Text(lesson['hi']!,style:const TextStyle(fontSize:16,color:Colors.black54)),
      const SizedBox(height:18),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:_speak,icon:const Icon(Icons.volume_up),label:const Text('Listen'))),const SizedBox(width:10),Expanded(child:FilledButton.icon(onPressed:_listen,icon:Icon(listening?Icons.stop:Icons.mic),label:Text(listening?'Stop':'Speak')))])
    ]))),
    const SizedBox(height:12),const Text('What we heard',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(heard.isEmpty?'Your recognised words will appear here.':heard,style:const TextStyle(fontSize:17)))),
    FilledButton(onPressed:(){setState(()=>message=feedback());widget.onComplete();},child:const Text('Get practice feedback')),
    Card(color:const Color(0xFFE8ECFF),child:Padding(padding:const EdgeInsets.all(16),child:Text(message))),
    OutlinedButton.icon(onPressed:(){setState(()=>index=(index+1)%lessons.length);},icon:const Icon(Icons.skip_next),label:const Text('Next sentence')),
    const Padding(padding:EdgeInsets.only(top:10),child:Text('Note: speech recognition may require internet and device speech services. Pronunciation feedback is practice guidance, not a certified score.',style:TextStyle(fontSize:12,color:Colors.black54)))
  ]);
}

class TutorScreen extends StatefulWidget { const TutorScreen({super.key}); @override State<TutorScreen> createState()=>_TutorScreenState(); }
class _TutorScreenState extends State<TutorScreen>{
 final input=TextEditingController(); final List<Map<String,String>> chat=[{'who':'tutor','text':'Hi! I am your English practice tutor. Try: “Tell me about your school.”'}];
 void send(){final s=input.text.trim();if(s.isEmpty)return;setState((){chat.add({'who':'you','text':s});chat.add({'who':'tutor','text':_reply(s)});input.clear();});}
 String _reply(String s){final x=s.toLowerCase();if(x.contains('my name'))return 'Nice to meet you! A useful pattern is: “My name is ___. I study in class __.” अब अपने बारे में एक और वाक्य लिखें।';if(x.contains('school'))return 'You can say: “My school is near my home. I enjoy learning with my friends.” Try making your own sentence.';if(x.contains('yesterday'))return 'For yesterday, use the past tense. Example: “Yesterday, I played cricket.” What did you do yesterday?';if(x.contains('he go')||x.contains('she go'))return 'Grammar tip: in the simple present, say “He goes” or “She goes.” Try another sentence.';return 'Good attempt! A clear sentence pattern is Subject + Verb + Object. Example: “I read a book.” Try writing your idea in a short English sentence. (Offline demo tutor: connect an AI backend for open-ended replies.)';}
 @override void dispose(){input.dispose();super.dispose();}
 @override Widget build(BuildContext context)=>Column(children:[
  Container(width:double.infinity,color:const Color(0xFFE8ECFF),padding:const EdgeInsets.all(16),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('AI conversation practice',style:TextStyle(fontSize:21,fontWeight:FontWeight.bold)),SizedBox(height:4),Text('Practise freely. This starter includes sample offline replies; full generative AI needs a secure backend and internet.') ])),
  Expanded(child:ListView(padding:const EdgeInsets.all(14),children:chat.map((m)=>Align(alignment:m['who']=='you'?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.symmetric(vertical:5),padding:const EdgeInsets.all(13),constraints:const BoxConstraints(maxWidth:310),decoration:BoxDecoration(color:m['who']=='you'?blue:Colors.white,borderRadius:BorderRadius.circular(16)),child:Text(m['text']!,style:TextStyle(color:m['who']=='you'?Colors.white:navy,fontSize:15))))).toList())),
  SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:input,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Type an English sentence',border:OutlineInputBorder(),filled:true))),const SizedBox(width:8),IconButton.filled(onPressed:send,icon:const Icon(Icons.send))])))
 ]);
}

class ProgressScreen extends StatelessWidget {
 const ProgressScreen({super.key});
 @override Widget build(BuildContext context)=>FutureBuilder<SharedPreferences>(future:SharedPreferences.getInstance(),builder:(c,s){final count=s.data?.getInt('completed')??0;final grade=s.data?.getInt('grade')??10;return ListView(padding:const EdgeInsets.all(20),children:[const Text('Your progress',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:16),Card(child:ListTile(leading:const Icon(Icons.school,color:blue),title:Text('Class $grade'),subtitle:const Text('Your selected class'))),Card(child:ListTile(leading:const Icon(Icons.check_circle,color:Colors.green),title:Text('$count practice sessions'),subtitle:const Text('Keep practising every day'))),const SizedBox(height:12),const Text('A simple routine',style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('1. Listen to 5 sentences\\n2. Speak for 5 minutes\\n3. Learn 3 new phrases\\n4. Review one grammar rule')))]);});
}
